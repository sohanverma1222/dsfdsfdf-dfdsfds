// VideoList.js
import React from 'react';
import Video from './Video';

const VideoList = ({ videos }) => {
    return (
        <ul className="video-list">
            {videos.map((video, index) => (
                <li key={index}>
                    <Video
                        title={video.title}
                        src={video.src}
                        description={video.description}
                    />
                </li>
            ))}
        </ul>
    );
};

export default VideoList;
