// Page1.js
import React from 'react';
import VideoList from "./VideoFrame/VideoList";
import './Page1.css';

const Page1 = () => {

    const videos = [
        {
            title: 'First Videos 1',
            src: 'https://www.youtube.com/embed/E7wJTI-1dvQ',
            description: 'Description for Video 1',
        },
        {
            title: 'Video 2',
            src: 'https://www.dailymotion.com/embed/video/x7uh7tb',
            description: 'Description for Video 2',
        },
        {
            title: 'Video 3',
            src: 'https://www.youtube.com/embed/video2',
            description: 'Description for Video 3',
        },
        {
            title: 'Video 2',
            src: 'https://www.youtube.com/embed/video2',
            description: 'Description for Video 2',
        },
        {
            title: 'Video 2',
            src: 'https://www.youtube.com/embed/video2',
            description: 'Description for Video 2',
        },
        {
            title: 'Video 2',
            src: 'https://www.youtube.com/embed/video2',
            description: 'Description for Video 2',
        },
        {
            title: 'Video 2',
            src: 'https://www.youtube.com/embed/video2',
            description: 'Description for Video 2',
        },
        {
            title: 'Video 2',
            src: 'https://www.youtube.com/embed/video2',
            description: 'Description for Video 2',
        },
        {
            title: 'Video 2',
            src: 'https://www.youtube.com/embed/video2',
            description: 'Description for Video 2',
        },
        // Add more video data as needed
    ];


    return (
       /* <div>
            <h2 >Page 1 Content</h2>
            <p>This is the content for Page 1.</p>

            <iframe src='https://www.youtube.com/embed/E7wJTI-1dvQ'
                    frameBorder='0'
                    allow='autoplay; encrypted-media'
                    allowFullScreen
                    title='video'
                    className="iframe"
            />

        </div>*/


        <div className="app">
            <h1 className="video-list_111">Video List</h1>
            <VideoList videos={videos} />
        </div>

    );
};

export default Page1;
