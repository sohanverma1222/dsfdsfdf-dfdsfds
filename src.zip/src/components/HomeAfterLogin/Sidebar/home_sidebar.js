import React from 'react';

const home_sidebar = () => {
    return (
        <div>
            <h1>sohan verma home page of the sidebar</h1>
        </div>
    );
};

export default home_sidebar;
