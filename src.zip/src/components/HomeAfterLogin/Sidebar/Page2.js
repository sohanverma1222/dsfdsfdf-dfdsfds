// Page1.js
import React from 'react';

const Page2 = () => {
    return (
        <div>
            <h2 >Page 2 Content</h2>
            <p>This is the content for Page 2.</p>
        </div>
    );
};

export default Page2;
