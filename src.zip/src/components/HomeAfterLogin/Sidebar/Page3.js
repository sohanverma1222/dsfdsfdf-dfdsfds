// Page1.js
import React from 'react';

function handleLogin() {
    console.log("click the button");
}

const Page3 = () => {

    return (
        <div>
            <h2 >Page 3 Content</h2>
            <p>This is the content for Page 3.</p>

            <button onClick={handleLogin}>sohan</button>
        </div>
    );
};

export default Page3;
