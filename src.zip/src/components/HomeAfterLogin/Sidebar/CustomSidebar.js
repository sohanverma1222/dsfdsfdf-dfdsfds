/*
// CustomSidebar.js
import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
    return (
        <div className="sidebar">
            <ul>
                <li>
                    <Link to="/dashboard">Dashboard</Link>
                </li>
                <li>
                    <Link to="/profile">Profile</Link>
                </li>
                {/!* Add more sidebar links as needed *!/}
            </ul>
        </div>
    );
};

export default Sidebar;
*/
/*

// CustomSidebar.js
import React, { Component } from 'react';
import Sidebar from 'react-sidebar';

class CustomSidebar extends Component {
    state = {
        sidebarOpen: false,
    };

    onSetSidebarOpen = (open) => {
        this.setState({ sidebarOpen: open });
    };

    render() {
        return (
            <Sidebar
                sidebar={
                    <div>
                        <ul>
                            <li>Link 1</li>
                            <li>Link 2</li>
                            <li>Link 3</li>
                        </ul>
                    </div>
                }
                open={this.state.sidebarOpen}
                onSetOpen={this.onSetSidebarOpen}
                styles={{ sidebar: { background: '#333', width: '250px' } }}
            >
                <button onClick={() => this.onSetSidebarOpen(true)}>
                    Open Sidebar
                </button>
                <div className="content">{this.props.children}</div>
            </Sidebar>
        );
    }
}

export default CustomSidebar;
*/

// CustomSidebar.js
// import React from 'react';
// import { Link } from 'react-router-dom';
// import './Sidebar.css';
//
// const CustomSidebar = () => {
//     return (
//         <div className="fixed-sidebar">
//             <div>
//                 <ul>
//                     <li>
//                         <Link to="/page1">Link 1</Link>
//                     </li>
//                     <li>
//                         <Link to="/page2">Link 2</Link>
//                     </li>
//                     <li>
//                         <Link to="/page3">Link 3</Link>
//                     </li>
//                 </ul>
//             </div>
//         </div>
//     );
// };
//
// export default CustomSidebar;

// CustomSidebar.js
import React from 'react';
import { Link } from 'react-router-dom';
import "./Sidebar.css"

const CustomSidebar = () => {
    return (
        <div className="fixed-sidebar">
            <ul>
                <li>
                    <Link to="/page1">Link 1</Link>
                </li>
                <li>
                    <Link to="/page2">Link 2</Link>
                </li>
                <li>
                    <Link to="/page3">Link 3</Link>
                </li>
            </ul>
        </div>
    );
};

export default CustomSidebar;
