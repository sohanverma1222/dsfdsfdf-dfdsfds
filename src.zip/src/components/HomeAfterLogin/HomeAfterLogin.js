/*
/!*
// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Sidebar from "./Sidebar/Sidebar";
import Dashboard from "./Sidebar/Dashboard";
import Profile from "./Sidebar/Profile";


function HomeAfterLogin() {
    return (
        <Router>
            <Sidebar />
            <Switch>
                {/!* Define your routes here *!/}
                <Route path="/dashboard" component={Dashboard} />
                <Route path="/profile" component={Profile} />
                {/!* Add more routes as needed *!/}
            </Switch>
        </Router>
    );
}

export default HomeAfterLogin;
*!/


// App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import CustomSidebar from './Sidebar/CustomSidebar';
import './Sidebar/Sidebar.css';
import Page1 from "./Sidebar/Page1";

function App() {
    return (
        <Router>
            <div className="app">
                <CustomSidebar />
                <div className="content">
                    <Switch>
                        <Route path="/page1" component={Page1} />
                        {/!*<Route path="/page2" component={Page2} />
                        <Route path="/page3" component={Page3} />*!/}
                    </Switch>
                </div>
            </div>
        </Router>
    );
}

export default App;
*/


// App.js
import React from 'react';
import {BrowserRouter as Router, Redirect, Route, Switch, useHistory} from 'react-router-dom';
import CustomSidebar from './Sidebar/CustomSidebar';
import Page1 from './Sidebar/Page1';
import './Sidebar/HomeAfterLogin.css';
import Page2 from "./Sidebar/Page2";
import Page3 from "./Sidebar/Page3";

function dsddd() {
    console.log("logout")
}

function App() {

    const history = useHistory();

    const handleLogout = () => {
        // Perform any logout actions (e.g., clearing user data, authentication state, etc.)

        // Redirect to the login page
        history.push('/login');
    };

    return (
        <>
            <img className="circular-image top-right" src={require("./Sidebar/sohan1.jpeg").default}  alt="logo"/>
            <button className="top-right" onClick={handleLogout}>logout</button>
        <Router>
            <div className="app">
                <CustomSidebar />
                <div className="content-container">
                    <Switch>
                        <Route path="/page1" component={Page1} />
                        <Route path="/page2" component={Page2} />
                        <Route path="/page3" component={Page3} />
                        <Redirect to="/page1" />
                    </Switch>
                </div>


            </div>
        </Router>

{/*    <button className="clickedshift">dsjfldksjf  </button>*/}



    </>
    );
}

export default App;
