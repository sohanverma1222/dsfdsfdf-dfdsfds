
let categories = [
	{
		img: require('../../../images/categories/c1.svg'),
		name: 'web development'
	},
	{
		img: require('../../../images/categories/c2.svg'),
		name: 'cybersecurity'
	},
	{
		img: require('../../../images/categories/c3.svg'),
		name: 'design'
	},
	{
		img: require('../../../images/categories/c4.svg'),
		name: 'data analysis'
	},
	{
		img: require('../../../images/categories/c5.svg'),
		name: 'SEO'
	}
]

export {categories}