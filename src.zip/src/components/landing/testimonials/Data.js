
let tes = [
	{
		img: require('../../../images/tes/1.jpg'),
		name: 'alfredo traviski',
		skill: 'UI/UX Designer'
	},
	{
		img: require('../../../images/tes/2.jpg'),
		name: 'André gohan',
		skill: 'Full Stack Developer'
	},
	{
		img: require('../../../images/tes/3.jpg'),
		name: 'gilberto Mariano',
		skill: 'Ex Student'
	}
]

export {tes}