// src/components/Login.js
import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import './Login.css';


function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const history = useHistory();


    const centerStyle = {
        marginLeft: '525px',
        width: '300px',
    };


    const handleLogin = () => {
        axios.post('http://192.168.1.12:5000/login', { username, password })
            .then((response) => {
                if (response.status === 200) {
                    setMessage('Login successful');
                    //for the redirect the page from the login page to the homepage
                    history.push('/HomeAfterLogin');
                } else {
                    setMessage('Login failed');
                }
            })
            .catch((error) => {
                setMessage('Login failed');
                console.error('Error:', error);
            });
    };

    return (
        <>
            <div style={centerStyle}>
                <h1 className='fancy-heading_login'>Login</h1>
                <div >
                    <input
                        type="text"
                        placeholder="Username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="styled-input"
                    />
                </div>
                <div>
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="styled-input"
                    />
                </div>
                <div>
                    <button className="rectangular-button" onClick={handleLogin}>Login</button>
                </div>
                <div>
                    <p>{message}</p>
                </div>
            </div>
        </>
    );
}

export default Login;
