import React, {Component} from 'react'
import {BrowserRouter, Route, Switch} from 'react-router-dom'
import Pagination from '../pagination/Pagination'
import Section1 from './sections/section1/Section1'
import Section2 from './sections/section2/Section2'
import Section3 from './sections/section3/Section3'
import './Blogs.css'
import About from "../about/About";
import {Redirect} from "react-router";
import Landing from "../landing/Landing";

class Blogs extends Component
{
	state = {
		array: [
			{
				path: '/blogs/',
				number: 1
			},
			{
				path: '/blogs/section2',
				number: 2
			},
			{
				path: '/blogs/section3',
				number: 3
			}
		]
	}
	render()
	{
		return (
			<BrowserRouter>
				<div className = 'container'>
					<div className = 'title py-3 text-center'>
						<h4 className = 'sub-title text-capitalize'>read our <span>blogs</span></h4>
					</div>
				</div>
				<Pagination array = {this.state.array}/>
				<Switch>
					<Route path = '/'> <Section1 /> </Route>

					<Route path = '/blogs/section2' component = {Section2} />
					<Route path = '/blogs/section3' component = {Section3} />
				</Switch>
				<Pagination array = {this.state.array}/>
			</BrowserRouter>
		)
	}
}

export default Blogs
