
let teachers = [
	{
		name: 'amanda perreira',
		material: 'web development',
		img: require('../../../images/teachers/1.jpg'),
	},
	{
		name: 'jessica braston',
		material: 'cybersecurity',
		img: require('../../../images/teachers/2.jpg')
	},
	{
		name: 'gustavo santos',
		material: 'design',
		img: require('../../../images/teachers/3.jpg')
	},
	{
		name: 'jack frido',
		material: 'data analysis',
		img: require('../../../images/teachers/4.jpg')
	},
	{
		name: 'alexandro silva',
		material: 'SEO',
		img: require('../../../images/teachers/5.jpg')
	},
	{
		name: 'Stela pyanka',
		material: 'algebra',
		img: require('../../../images/teachers/6.jpg')
	}
]

export {
	teachers
}