
let contact = [
	{
		info: 'openschool@support.com',
		icon: 'fas fa-envelope',
		cls: 'e-mail'
	},
	{
		info: '+1 206 555 0100',
		icon: 'fas fa-phone-alt',
		cls: 'phone-number'
	},
	{
		info: '721 S Warren AveMalvern, Pennsylvania(PA), 1935',
		icon: 'fas fa-map-marker-alt',
		cls: 'location'
	}
]

export {contact}