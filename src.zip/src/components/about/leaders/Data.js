
let leaders = [
	{
		name: 'amine ait ouazghour',
		desc: 'full stack javascript developer, cyber security lover and problem solver',
		skills: 'Full Sack Developer | Pentester',
		nickname: "amaitou",
		avatar: require('../../../images/avatars/1.jpg')
	},
	{
		name: 'jackson eder',
		desc: 'passionate about cybersecurity and read teaming stuff',
		skills: 'Back-end Developer | Pythoner',
		nickname: "j4ck5on",
		avatar: require('../../../images/avatars/2.jpg')
	},
	{
		name: 'patrick pavarice',
		desc: 'creative with a way you cannot even imagine',
		skills: 'UI/UX Designer',
		nickname: "c1c4d4",
		avatar: require('../../../images/avatars/3.jpg')
	}
]

export {leaders}
