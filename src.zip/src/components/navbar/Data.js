
let navbar_items = [
	{
		name: '',
		icon: 'fas fa-home',
	},
	{
		name: 'about',
		icon: 'fas fa-address-card',
	},
	{
		name: 'blogs',
		icon: 'fas fa-blog',
	},
	{
		name: 'courses',
		icon: 'fas fa-book-open',
	},
	{
		name: 'contact',
		icon: 'fas fa-phone-alt',
	},
	{
		name: 'Login',
		icon: 'fas fa-sign-in-alt',
	}
]

export {
	navbar_items
}
