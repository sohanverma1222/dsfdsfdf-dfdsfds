import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import Pagination from '../pagination/Pagination';
import Section1 from './sections/section1/Section1';
import Section2 from './sections/section2/Section2';

class Courses extends Component {
	state = {
		array: [
			{
				path: '/courses',
				number: 1
			},
			{
				path: '/courses/section2',
				number: 2
			}
		]
	};

	render() {
		return (
			<BrowserRouter>
				<div className='container'>
					<div className='title py-3 text-center'>
						<h4 className='sub-title text-capitalize'>
							browse our <span>courses</span>
						</h4>
					</div>
				</div>
				<Pagination array={this.state.array} />

				<Switch>
					<Route path='/courses/section2'>
						<Section2 />
					</Route>
					<Route path='/courses'>
						<Section1 />
					</Route>
				</Switch>

				<Pagination array={this.state.array} />
			</BrowserRouter>
		);
	}
}

export default Courses;
