import React, { useState } from 'react';
import { section1, sectionTitles } from './Data';
import './Section1.css';
import { toast, ToastContainer } from 'react-toastify';
import { useHistory } from 'react-router-dom';
import { Link } from 'react-router-dom';

const pageNames = ['NewPage.js', 'NewPage2.js', 'NewPage3.js'];

const Section1 = () => {
    const [index, setIndex] = useState(0);
    const history = useHistory();

    const onButtonClick = (courseIndex) => {
        const pageName = pageNames[courseIndex];
        if (pageName === 'NewPage.js') {
            console.log(pageName);
            window.open('/NewPage', '_self');
            // history.push('/NewPage');
        } else if (pageName === 'NewPage2.js') {
            console.log(pageName);
            history.push('/NewPage2');
            window.open('/NewPage2', '_self');
            // <Link to="/NewPage2"/>
        } else if (pageName === 'NewPage3.js') {
            console.log(pageName);
            history.push('/NewPage3');
            window.open('/NewPage3', '_self');
        }
    };

    return (
        <div className='s1 py-5'>
            <div className='container'>
                <div className='d d-flex flex-wrap justify-content-center'>
                    {section1.map((item, courseIndex) => (
                        <div className='b mb-5 text-center p-3 shadow rounded mx-2' key={courseIndex}>
                            <img className='img-fluid mb-3' src={item.default} alt='course' />
                            <p className='title'>{sectionTitles[courseIndex]}</p>
                            <button onClick={() => onButtonClick(courseIndex)}>View Course</button>
                        </div>
                    ))}
                </div>
            </div>
            <ToastContainer />
        </div>
    );
};

export default Section1;

