import React from 'react';

const NewPage2 = () => {
    return (
        <div>
            <h1>sohan verma</h1>
        </div>
    );
};


export default NewPage2;
