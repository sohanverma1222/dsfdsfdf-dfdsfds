import React from 'react';
import AccordionItem from "./testing/AccordionItem";
import CourseDescription from "./testing/CourseDescription";
import MyComponent from "./testing/MyComponent";

const NewPage = () => {
    return (
           <section>
               <AccordionItem />
               <CourseDescription />
               <MyComponent />
           </section>
    );
};


export default NewPage;
