import React from 'react';
import '../testing/CourseDescription.css'; // Import your CSS file

function CourseDescription() {
    return (
        <>

        </>
    );
}

export default CourseDescription;
