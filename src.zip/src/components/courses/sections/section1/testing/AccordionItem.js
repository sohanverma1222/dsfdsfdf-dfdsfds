import React, { useState } from 'react';

function AccordionItem({ title, content }) {
    const [isOpen, setIsOpen] = useState(false);

    const toggleAccordion = () => {
        setIsOpen(!isOpen);
    };

    return (
        <div className="accordion-row rounded-sm shadow-lg border mt-20 py-20 px-35">
            <div className="font-weight-bold font-14 text-secondary" role="tab" id={title}>
                <div
                    onClick={toggleAccordion}
                    className="d-flex align-items-center justify-content-between"
                    role="button"
                >
                    <span>{title}</span>
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="25"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        className={`feather collapse-chevron-icon ${
                            isOpen ? 'feather-chevron-up' : 'feather-chevron-down'
                        }`}
                    >
                        <polyline points="6 9 12 15 18 9" />
                    </svg>
                </div>
            </div>
            <div
                id={title}
                className={`collapse ${isOpen ? 'show' : ''}`}
                role="tabpanel"
                style={{ marginTop: '10px' }}
            >
                <div className="panel-collapse text-gray">{content}</div>
            </div>
        </div>
    );
}

function Accordion() {
    return (
        <div>
            <AccordionItem
                title="What is the course level?"
                content="This is a course for beginners so you will get familiar with the topic from scratch."
            />
            <AccordionItem
                title="What is the course level?"
                content="This is a course for beginners so you will get familiar with the topic from scratch."
            />
            <AccordionItem
                title="What is the course level?"
                content="This is a course for beginners so you will get familiar with the topic from scratch."
            />

            {/* Add more AccordionItem components as needed */}
        </div>
    );
}

export default Accordion;
