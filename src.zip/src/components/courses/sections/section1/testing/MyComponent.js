import {useState} from 'react';
import './MyComponent.css'; // Import your custom CSS here

import {toast, ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';



const MyComponent = () => {

    // pop up window code
    const [isOpen, setIsOpen] = useState(false);
    const [name, setName] = useState('');

    const [email, setEmail] = useState('');

    const openPopup = () => {
        setIsOpen(true);
    };

    const closePopup = () => {
        setIsOpen(false);
    };

    const handleNameChange = (e) => {
        setName(e.target.value);
    };

    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Do something with the 'name' data, e.g., send it to a server
        console.log('Name submitted:', name);
        console.log('Email submitted:', email);
        toast.success('We will contact you shortly.', {
            position: 'top-right',
            autoClose: 3000,
        });
        closePopup();
    };

    // ddd


    return (
        <section>

            <div className="top_marign">
                <div className="container">
                    <div className="d-flex w-100 h-100">
                        <div className="mr-auto align-middle">
                            {/*<img src="https://dummyimage.com/90x60/000/fff" className="img-fluid" alt="logo"/>*/}
                            <img src={require("../computer.png").default} className="img-fluid" alt="logo"/>
                        </div>
                        <div className="align-middle">

                        </div>
                    </div>
                </div>
            </div>

            <div class="course-in-detail">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card left">
                                <div class="course-title-single">
                                    <h1 class="bold">UI-UX Web Design, Graphic Design</h1>

                                    <div class="course-widget-price d-none d-sm-block">
                                        <h4 class="course-title">COURSE FEATURES</h4>
                                        <ul>
                                            <li>
                                                <i class="fa fa-clock-o" aria-hidden="true"></i>
                                                <span>Starts</span>
                                                <span class="time">May 29, 2016</span>
                                            </li>
                                            <li>
                                                <i class="fa fa-exclamation-circle" aria-hidden="true"></i>
                                                <span>Duration</span>
                                                <span class="time">2 Months</span>
                                            </li>
                                            <li>
                                                <i class="fa fa-leanpub" aria-hidden="true"></i>
                                                <span>Class Duration</span>
                                                <span class="time">7:00 - 9:00</span>
                                            </li>
                                            <li>
                                                <i class="fa fa-graduation-cap" aria-hidden="true"></i>
                                                <span>Institution</span>
                                                <span class="time">ABC University</span>
                                            </li>
                                            <li>
                                                <i class="fa fa-user-plus" aria-hidden="true"></i>
                                                <span>Seats Available</span>
                                                <span class="time">23 Student</span>
                                            </li>
                                            <li>
                                                <i class="fa fa-users" aria-hidden="true"></i>
                                                <span>Level</span>
                                                <span class="time">All level</span>
                                            </li>
                                        </ul>
                                        <h5 class="bt-course">Course Price: 270.00 <span class="small"> (INR)</span>
                                        </h5>
                                        {/*<a class="flat-button bg-orange btn btn-block" onClick={showPopup}>Enroll this Course</a>*/}
                                        {/*  <button class="flat-button bg-orange btn btn-block" id="openPopup" href="#">Enroll this
                                            Course
                                        </button>*/}

                                        <button className="flat-button bg-orange btn btn-block" onClick={openPopup}>
                                            Enroll this Course
                                        </button>

                                        {isOpen && (
                                            <div className="popup">
                                                <div className="popup-content">
                                                    <h2>Enroll in the Course</h2>
                                                    <form onSubmit={handleSubmit}>
                                                        <label>
                                                            Name:
                                                            <input type="text" value={name}
                                                                   onChange={handleNameChange}/>
                                                        </label>
                                                        <label>
                                                            Email:
                                                            <input type="email" value={email}
                                                                   onChange={handleEmailChange}/>
                                                        </label>
                                                        <button type="submit">Submit</button>
                                                    </form>
                                                    <button type="submit" onClick={closePopup}>Close</button>
                                                </div>
                                            </div>
                                        )}
                                        <ToastContainer/>


                                    </div>


                                    <div class="entry-content">
                                        <h4 class="title-1">About the Course</h4>
                                        <p>
                                            Fusce eleifend donec sapien sed phase lusa. Pellentesque lacus vamus lorem
                                            arcu semper duiac. Cras ornare arcu avamus nda leo. Etiam ind arcu morbi
                                            justo mauris tempus pharetra interdum at congue semper purus.
                                        </p>

                                        <div class="flat-spacer h8px"></div>
                                        <h4 class="title-1">What You Will Learn</h4>
                                        <p>
                                            Fusce eleifend donec sapien sed phase lusa pellentesque lacus.Vivamus lorem
                                            arcu semper duiac. Cras ornare arcu avamus nda leo Etiam ind arcu. Morbi
                                            justo mauris tempus pharetra interdum at congue semper purus. Lorem ipsum
                                            dolor sit
                                        </p>
                                        <p class="marginbt-12px">
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod
                                            tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam,
                                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                            consequat.
                                        </p>
                                        <ul class="flat-list color-black">
                                            <li>2 Glossaries for difficult terms &amp; acronyms</li>
                                            <li>25 hours of High Quality e-Learning content</li>
                                            <li>72 end of chapter quizzes</li>
                                            <li>30 PDUs Offered</li>
                                            <li>Collection of 47 six sigma tools for hands-on practice</li>
                                        </ul>

                                        <p class="mgbt-36">
                                            Fusce eleifend donec sapien sed phase lusa. Pellentesque lacus vamus lorem
                                            arcu semper duiac. Cras ornare arcu avamus nda leo. Etiam ind arcu morbi
                                            justo mauris tempus pharetra interdum at congue semper purus. Lorem ipsum
                                            dolor sit amet sed consectetur adipisicing elit sed do eiusmod tempor
                                            incididunt.
                                        </p>

                                        <h4 class="title-1">What You Will Learn</h4>
                                        <p class="mgbt-48">
                                            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
                                            eu fugiat nulla pariatur. Excepteur sint occa ecatedcupida tat non proident,
                                            sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut
                                            perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                            doloremque laudantium, totam rem aperiam eaque ipsa quae ab illo inventore
                                            veritatis etuquasi architect obeatae vitae dicta sunt explicabo nemo enim
                                            ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit sed quia
                                            consequun tur magni.
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 our-features">

                            <h3 class="headline text-center ">Why we are Different</h3>

                            <div class="row">
                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            {/*<img src="" class="img-fluid"*/}
                                            <img src={require("../computer.png").default} class="img-fluid"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4 col-sm-6 mr-b-4">

                                    <div class="featured-service">
                                        <div class="media">
                                            <img src="https://dummyimage.com/70x70/000/fff" class="img-fluid"
                                                 alt="icon"/>
                                            <div class="media-body">
                                                <h4>Painting</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>


                <section class="bg-light course-materials">
                    <div class="container">
                        <h3 class="headline text-center ">Course Materials</h3>
                        <div class="row">
                            <div class="col-md-6 col-sm-6 mr-b-4">

                                <a href="">
                                    <div class="course-card">
                                        <div class="media"><img src="https://dummyimage.com/70x70/000/fff"
                                                                class="img-fluid" alt="icon"/>
                                            <div class="media-body">
                                                <h4>Study Materials</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-6 col-sm-6 mr-b-4">

                                <a href="">
                                    <div class="course-card">
                                        <div class="media"><img src="https://dummyimage.com/70x70/000/fff"
                                                                class="img-fluid" alt="icon"/>
                                            <div class="media-body">
                                                <h4>Exam Registration</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-6 col-sm-6 mr-b-4">

                                <a href="">
                                    <div class="course-card">
                                        <div class="media"><img src="https://dummyimage.com/70x70/000/fff"
                                                                class="img-fluid" alt="icon"/>
                                            <div class="media-body">
                                                <h4>Time Table</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-6 col-sm-6 mr-b-4">
                                <a href="">
                                    <div class="course-card">
                                        <div class="media"><img src="https://dummyimage.com/70x70/000/fff"
                                                                class="img-fluid" alt="icon"/>
                                            <div class="media-body">
                                                <h4>Exam Result</h4>
                                                <p>A fresh coat of paint can breathe life into any room.</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>

                        </div>

                    </div>
                </section>
            </div>
        </section>


    );
};

export default MyComponent;
