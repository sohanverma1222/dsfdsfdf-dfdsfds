let section1 = [
	require('../../../../images/courses/1.svg'),
	require('../../../../images/courses/2.svg'),
	require('../../../../images/courses/3.svg'),
	require('../../../../images/courses/4.svg'),
	require('../../../../images/courses/5.svg'),
	require('../../../../images/courses/6.svg'),
	require('../../../../images/courses/7.svg'),
	require('../../../../images/courses/8.svg'),
	require('../../../../images/courses/9.svg'),
	require('../../../../images/courses/10.svg'),
	require('../../../../images/courses/11.svg'),
	require('../../../../images/courses/12.svg')
];

let sectionTitles = [
	"Introduction to React",
	"Building React Components",
	"State and Props",
	"Routing in React",
	"Forms in React",
	"Redux in React",
	"Testing React Components",
	"Deploying React Applications",
	"Advanced React Topics",
	"React Native",
	"Next.js",
	"Other React Frameworks"
];

export {
	section1,
	sectionTitles
};
