import React from 'react';


const NewPage3 = () => {
    return (
        <div>
            Third Page
        </div>
    );
};

export default NewPage3;
