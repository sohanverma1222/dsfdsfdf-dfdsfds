/*
import React, { Component } from 'react';
import { BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import Navbar from './components/navbar/Navbar';
import Footer from './components/footer/Footer';
import Landing from './components/landing/Landing';
import About from './components/about/About';
import Blogs from './components/blogs/Blogs';
import Sb from './components/scrollbtn/Sb';
import Courses from './components/courses/Courses';
import Contact from './components/contact/Contact';
import Notfound from './components/notfound/Notfound';
import NewPage from "./components/courses/sections/section1/NewPage";
// import NewPage2 from "./components/courses/sections/section1/NewPage2";
// import blogs from "./components/blogs/Blogs";

import NewPage2 from "./components/courses/sections/section1/NewPage2";
import NewPage3 from "./components/courses/sections/section1/NewPage3";
import Login from "./components/login/Login";
import HomeAfterLogin.css from "./components/HomeAfterLogin.css/HomeAfterLogin.css";


class AuthenticatedLayout extends Component {
    render() {
        return (
            <div>
                {this.props.children}
             <h1>sdf</h1>
            </div>
        );
    }
}

class App extends Component {
    render() {
        return (
            <BrowserRouter>
                <>
                    <Sb />
                    <div className = '_navbar'>
                        <Navbar />
                    </div>

                    <div className = '_body'>
                        {/!*<Router>*!/}
                        <Switch>
                            <Route exact path = '/'> <Landing /> </Route>

                            <Route exact path = '/about'> <About /> </Route>
                            <Route exact path ='/blogs'> <Blogs /> </Route>
                            <Route exact path ='/courses'> <Courses /> </Route>
                            <Route exact path ='/contact'> <Contact /> </Route>
                            <Route exact path ='/login'> <Login /> </Route>




                            {/!*<Route exact path ='/NewPage'> <NewPage /> </Route>*!/}

                            <Route exact path ='/NewPage'> <NewPage /> </Route>
                            <Route exact path ='/NewPage2'> <NewPage2 /> </Route>
                            <Route exact path ='/NewPage3'> <NewPage3 /> </Route>

                            {/!*<Route path="/NewPage" component={NewPage} />*!/}

                            {/!*<Route exact path ='/HomeAfterLogin.css'> <HomeAfterLogin.css /> </Route>*!/}
{/!*
                            <Route exact path="/HomeAfterLogin.css">
                                <AuthenticatedLayout>
                                    <HomeAfterLogin.css />
                                </AuthenticatedLayout>
                            </Route>*!/}

                            {/!* Use AuthenticatedLayout for HomeAfterLogin.css *!/}
                            <Route exact path="/HomeAfterLogin.css">
                                <AuthenticatedLayout>
                                    <HomeAfterLogin.css />
                                </AuthenticatedLayout>
                            </Route>

                            <Route exact path = '*'> <Notfound /> </Route>

                        </Switch>

                        {/!*</Router>*!/}
                    </div>

                    <div className = '_footer'>
                        <Footer />
                    </div>

                </>
            </BrowserRouter>
        );
    }
}

export default App;


*/

import React, { Component } from 'react';
import {BrowserRouter, Switch, Route, Link, Router} from 'react-router-dom';
import Navbar from './components/navbar/Navbar';
import Footer from './components/footer/Footer';
import Landing from './components/landing/Landing';
import About from './components/about/About';
import Blogs from './components/blogs/Blogs';
import Sb from './components/scrollbtn/Sb';
import Courses from './components/courses/Courses';
import Contact from './components/contact/Contact';
import Notfound from './components/notfound/Notfound';
import NewPage from "./components/courses/sections/section1/NewPage";
import NewPage2 from "./components/courses/sections/section1/NewPage2";
import NewPage3 from "./components/courses/sections/section1/NewPage3";
import Login from "./components/login/Login";
import HomeAfterLogin from "./components/HomeAfterLogin/HomeAfterLogin";

class App extends Component {

    render() {
        return (
            <BrowserRouter>
                <>
                    <Sb />
                    <div className = '_navbar'>
                        <Switch>
                            <Route exact path = '/'> <Navbar /> </Route>
                            <Route exact path = '/about'> <Navbar /> </Route>
                            <Route exact path ='/blogs'> <Navbar /> </Route>
                            <Route exact path ='/courses'> <Navbar /> </Route>
                            <Route exact path ='/contact'> <Navbar /> </Route>
                            <Route exact path = '/login'> <Navbar /> </Route>
                            <Route exact path ='/NewPage'> <Navbar /> </Route>
                            <Route exact path ='/NewPage2'> <Navbar /> </Route>
                            <Route exact path ='/NewPage3'> <Navbar /> </Route>
                            <Route exact path = '*'> <></> </Route>
                        </Switch>
                    </div>

                    <div className = '_body'>
                        <Switch>
                            <Route exact path = '/'> <Landing /> </Route>
                            <Route exact path = '/about'> <About /> </Route>
                            <Route exact path ='/blogs'> <Blogs /> </Route>
                            <Route exact path ='/courses'> <Courses /> </Route>
                            <Route exact path ='/contact'> <Contact /> </Route>
                            <Route exact path = '/login'> <Login /> </Route>
                            <Route exact path ='/NewPage'> <NewPage /> </Route>
                            <Route exact path ='/NewPage2'> <NewPage2 /> </Route>
                            <Route exact path ='/NewPage3'> <NewPage3 /> </Route>
                            <Route exact path = "/HomeAfterLogin"> <HomeAfterLogin /> </Route>
                            <Route exact path = '*'> <Notfound /> </Route>
                        </Switch>
                    </div>

                    <div className='_footer'>
                        <Switch>
                            <Route exact path='/'> <Footer /></Route>
                            <Route exact path='/about'> <Footer /></Route>
                            <Route exact path='/blogs'> <Footer /></Route>
                            <Route exact path='/courses'> <Footer /></Route>
                            <Route exact path='/contact'> <Footer /></Route>
                            <Route exact path='/login'> <Footer /></Route>
                            <Route exact path='/NewPage'> <Footer /></Route>
                            <Route exact path='/NewPage2'> <Footer /></Route>
                            <Route exact path='/NewPage3'> <Footer /></Route>
                            {/*<Route exact path='/HomeAfterLogin.css'><Footer /></Route>*/}
                            <Route exact path='*'><></></Route>
                        </Switch>
                    </div>

                </>

               {/* <Router>
                    <div className="App">
                        <HomeAfterLogin.css />
                    </div>
                </Router>*/}
            </BrowserRouter>


        );
    }
}

export default App;
